package org.oguz.spring.web.model.dao;

public interface FormValidationGroup
{

}
